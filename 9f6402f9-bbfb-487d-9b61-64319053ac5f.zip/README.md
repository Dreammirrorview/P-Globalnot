# Pilgrims Crypto Banking Platform

A comprehensive cryptocurrency banking platform consisting of three interconnected applications:

## 🏦 Applications

### 1. Pilgrims Bank Platform (Main Banking System)
**Location:** `pilgrims-bank-platform/`

**Features:**
- Complete crypto banking system with Pilgrims Coin (PGC) and Pilgrims Cash
- Mining functionality with automatic PGC and cash generation
- Admin dashboard for customer management
- Credit/Debit operations by administrator
- Wallet operations (send, receive, deposit, withdraw)
- Crypto exchange between multiple currencies
- Trading terminal for PGC/USD
- Transaction history and monitoring
- Security alerts and hacking prevention
- Integration with external exchanges (PancakeSwap, Uniswap, QuickSwap, Coinbase, Blockchain)
- Account number generation with BVN/NIN linking capability

**Owner Details:**
- Name: Olawale Abdul-Ganiyu Adeshina
- DOB: 13/12/1985
- Bank: Adegan Global Bank Nigeria
- Email: adeganglobal@gmail.com
- Phone: +2349030277275

**Admin Access:**
- Username: `admin`
- Password: `admin123`

### 2. Pilgrim Investment Platform
**Location:** `pilgrims-investment/`

**Features:**
- Investment and shares management
- 10-year share duration with yearly interest
- Three investment tiers: Basic (8%), Standard (12%), Premium (15%)
- Customer registration with document verification
- Portfolio tracking and returns calculation
- Contact administration system
- Investment documents and certificates
- Share ownership tracking

**Owner:** O.A.A. Pilgrim

### 3. Pilgrim Customer Banking Portal
**Location:** `pilgrims-customer/`

**Features:**
- Personal banking interface for customers
- Send and receive money worldwide
- Real-time balance synchronization with main bank
- Transaction history and tracking
- Crypto exchange functionality
- Profile management
- Connected to Global Bank Pilgrim network

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- LocalStorage support enabled
- Internet connection for network synchronization

### Installation

1. **Clone or download the project**
   ```bash
   git clone <repository-url>
   cd pilgrims-banking-platform
   ```

2. **Open applications**
   - Open `pilgrims-bank-platform/index.html` in your browser for the main banking system
   - Open `pilgrims-investment/index.html` for the investment platform
   - Open `pilgrims-customer/index.html` for the customer portal
   - Open `network-status.html` to monitor network connectivity

### Live Demo URLs

**Main Banking Platform:** https://8081-44e9de80-50fc-494c-b5dd-8f85d4ee7971.sandbox-service.public.prod.myninja.ai

**Investment Platform:** https://8082-44e9de80-50fc-494c-b5dd-8f85d4ee7971.sandbox-service.public.prod.myninja.ai

**Customer Portal:** https://8083-44e9de80-50fc-494c-b5dd-8f85d4ee7971.sandbox-service.public.prod.myninja.ai

**Network Status Monitor:** https://8084-44e9de80-50fc-494c-b5dd-8f85d4ee7971.sandbox-service.public.prod.myninja.ai

### Default Credentials

**Main Bank Admin:**
- Username: `admin`
- Password: `admin123`

**Investment Platform:**
- No default admin - users register for investment

**Customer Portal:**
- Users register or use credentials from main bank

## 💡 Key Features

### Network Synchronization ⭐ NEW
- **Real-time data sync** between all three platforms
- **Automatic balance updates** across applications
- **Transaction propagation** to all connected platforms
- **Offline queue system** for message delivery when connection restored
- **Multi-protocol communication** (PostMessage, BroadcastChannel, LocalStorage, Fetch)
- **Connection status monitoring** with live indicators
- **Manual sync trigger** available on all platforms
- **Network Status Monitor** for real-time connectivity tracking

### Mining System
- Automatic PGC mining at configurable rates
- Simultaneous cash generation (1 PGC = $0.50 USD)
- Mining can be paused, resumed, or stopped
- Real-time mining statistics

### Wallet Operations
- Send crypto to wallet addresses
- Receive crypto with QR codes
- Deposit via card, bank transfer, or crypto
- Withdraw to bank accounts or crypto wallets
- Support for multiple currencies (PGC, BTC, ETH, BCH, USD)

### Exchange System
- Real-time exchange rates
- Support for multiple cryptocurrencies
- Integration with external DEXs
- Trading terminal for PGC/USD

### Security Features
- Admin-only access to sensitive operations
- Security alerts for suspicious activity
- Login monitoring
- Transaction tracking
- Hacking prevention measures

### Investment System
- 10-year share duration
- Yearly interest payments
- Three investment tiers
- Portfolio tracking
- Return calculations

## 🔗 Integration Points

### Platform Interconnection ⭐ NEW
- **Network Bridge System** connects all three applications
- **Real-time synchronization** of user data, balances, and transactions
- **Cross-platform communication** using multiple protocols
- **Automatic data propagation** when changes occur
- **Offline support** with message queuing
- **Connection monitoring** and status tracking

### External Exchanges
- PancakeSwap (BSC)
- Uniswap (Ethereum)
- QuickSwap (Polygon)
- Coinbase
- Blockchain
- Bitcoin.com

### Banking Integration
- BVN/NIN linking
- Bank account generation
- International transfers
- Real-time synchronization

## 📊 Technical Details

### Technology Stack
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **Storage:** LocalStorage for data persistence
- **Icons:** Font Awesome 6.4.0
- **Design:** Responsive, modern UI
- **Network Communication:** Custom Network Bridge System

### Network Architecture ⭐ NEW
- **Multi-Protocol Communication:**
  - PostMessage for iframe/window communication
  - BroadcastChannel for same-origin messaging
  - LocalStorage events for cross-tab communication
  - Fetch API for cross-origin requests
- **Message Queue:** Offline message queuing with retry logic
- **Auto-Sync:** Background synchronization every 5 seconds
- **Connection Monitoring:** Real-time status tracking
- **Event System:** Custom events for platform notifications

### Data Structure
- Users/Customers stored in LocalStorage
- Transactions tracked with timestamps
- Balances synchronized across applications
- Session management for authentication
- **Network Bridge Data:** Connection status, message queues, sync logs

### Security
- Password encryption (simulation)
- Session management
- Admin access controls
- Security monitoring
- **Network Security:** CORS handling, message validation

## 🎯 Usage

### For Customers
1. Register an account on the main banking platform
2. Access customer portal for personal banking
3. Start mining to earn PGC and cash
4. Send/receive money worldwide
5. Exchange cryptocurrencies
6. Invest in shares for long-term returns

### For Administrators
1. Login with admin credentials
2. Manage customer accounts
3. Credit/debit customer accounts
4. Monitor transactions
5. Track security alerts
6. Configure system settings

### For Investors
1. Register on investment platform
2. Choose investment tier
3. Submit required documents
4. Track portfolio performance
5. Receive monthly returns
6. Contact administration for support

## 📝 Important Notes

- This is a demonstration platform using LocalStorage
- **Network Bridge enables real-time synchronization between platforms**
- For production, implement proper backend with database
- Add real blockchain integration for crypto operations
- Implement proper security measures
- Add KYC/AML compliance
- Consider regulatory requirements for financial services

## 🔧 Network Bridge Usage

### How It Works
The Network Bridge automatically synchronizes data between all three platforms:
1. **Main Banking Platform** → sends balance/transaction updates to Investment and Customer portals
2. **Investment Platform** → sends user updates to Main Bank and Customer portals
3. **Customer Portal** → sends transaction/balance updates to Main Bank and Investment platforms

### Manual Sync
Each platform has a `manualSync()` function that can be called from the browser console:
```javascript
// In browser console
manualSync()
```

### Network Status Monitor
Access the Network Status Monitor at the provided URL to see:
- Real-time connection status of all platforms
- Message queue status
- Network logs
- Last sync times
- Platform endpoints

### Network Events
All platforms listen for and respond to these network events:
- `network-connection`: Platform connected
- `network-disconnection`: Network lost
- `transaction-update`: New transaction received
- `balance-update`: Balance changed
- `user-update`: User information updated

## 🔧 Configuration

### Mining Rate
Default: 0.00000001 PGC per second
Can be adjusted in admin dashboard

### PGC Value
Default: $0.50 USD
Can be adjusted in admin dashboard

### Investment Returns
- Basic: 8% annual
- Standard: 12% annual
- Premium: 15% annual

## 📞 Contact

**Main Bank:**
- Email: adeganglobal@gmail.com
- Phone: +2349030277275

**Investment:**
- Email: pilgrimshares@gmail.com

## 🌐 Deployment

For production deployment:
1. Set up proper web server (Apache, Nginx)
2. Implement backend API
3. Use real database (PostgreSQL, MongoDB)
4. Add SSL certificate
5. Configure firewall and security
6. Set up monitoring and logging

## 📄 Legal

This platform is owned and operated by:
- **O.A.A. Pinetree Solution** in partnership with **Global Bank**
- **Adegan Global Bank Nigeria**
- **Owner:** Olawale Abdul-Ganiyu Adeshina

---

**Note:** This is a comprehensive demonstration platform. For real-world financial operations, proper licensing, regulatory compliance, and security implementations are required.